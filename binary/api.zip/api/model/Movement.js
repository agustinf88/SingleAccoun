class Movement {
  constructor(value) {
    this.date = new Date().toLocaleDateString();
    this.value = value;
  }
}

module.exports = Movement;
